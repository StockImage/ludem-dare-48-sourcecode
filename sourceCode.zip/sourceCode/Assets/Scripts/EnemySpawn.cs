using UnityEngine;

public class EnemySpawn : MonoBehaviour
{
    [SerializeField]
    private GameObject[] enemyArray;
    Vector3 pos;
    public int enemyID;
    public int quantity;
    private float timer = 0f;
    [SerializeField]
    private float timerMax = 0.7f; // time between each spawn

    //could probably do 2 arrays of item names and corresponding sprites instead of game objects as theyre identical
    private void Start()
    {
        pos = transform.position;
    }

    public void BeginSpawn(int amount){
        quantity = amount;
    }
    //the spawn controller will handle what and how many to spawn
    public void SpawnEnemy()
    {

        pos.x += Random.Range(-1.0f, 1.0f);
        pos.y += Random.Range(-1.0f, 1.0f);
        Instantiate(enemyArray[enemyID], pos, Quaternion.identity);
        
    }

    private void LateUpdate()
    {

        //count down to 0, then character is vulnerable again
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            timer = timerMax;
            if (quantity > 0)
            {
                quantity--;
                SpawnEnemy();
            }
            else {
                //destroy hole
                Destroy(gameObject);
            }
        }

    }
}
