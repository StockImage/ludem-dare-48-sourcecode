using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    [SerializeField]
    public GameObject pauseMenuUI;
    [SerializeField]
    public GameObject HUD;
    [SerializeField]
    public GameObject GameOverScreen;
    public void BeginGameOver() {
        pauseMenuUI.SetActive(false);
        HUD.SetActive(false);
        GameOverScreen.SetActive(true);
        return;
    }

    public void StartOver() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
