using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spit : MonoBehaviour
{
    private float timer = 0f;
    [SerializeField]
    private float timerMax = 3f; // time between each spit
    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;
    [SerializeField]
    private int bulletDamage = 2;
    [SerializeField]
    private float bulletForce = 10f;
    private void LateUpdate()
    {

        //count down to 0, then character is vulnerable again
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            timer = timerMax;
            SpitAcid();
        }
        
    }

    void SpitAcid() {

        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        bullet.GetComponent<Bullet>().damage = bulletDamage;

        Vector3 bulletDirection = firePoint.up * bulletForce;
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(bulletDirection, ForceMode2D.Impulse);

        return;

    }

}
