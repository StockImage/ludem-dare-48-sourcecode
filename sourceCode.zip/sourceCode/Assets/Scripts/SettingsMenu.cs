using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class SettingsMenu : MonoBehaviour
{
    private bool isFullscreen = true;
    public AudioMixer mixer;
    public AudioMixer musicMixer;
    public void SetVolume(float volume) {
        mixer.SetFloat("volume", volume);
    }

    public void SetMusicVolume(float volume)
    {
        musicMixer.SetFloat("musicVolume", volume);
    }

    public void ToggleFullscreen() {
        isFullscreen = !isFullscreen;
        Screen.fullScreen = isFullscreen;
    }

}
