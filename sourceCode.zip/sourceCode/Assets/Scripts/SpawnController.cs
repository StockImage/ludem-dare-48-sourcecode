using UnityEngine;

public class SpawnController : MonoBehaviour
{
    [SerializeField]
    private GameObject[] spawnPointArray;
    [SerializeField]
    public int waveNum = 1;
    [SerializeField]
    private int enemiesRemaining = 20;
    [SerializeField]
    private GameObject hole;

    public bool earnMoney = true;

    private float interval;
    private float intervalMax = 180f; //3 mins
    private void Start()
    {
        interval = intervalMax;
        NextWave();
    }

    public void EnemyDied() {
        enemiesRemaining--;
        if (enemiesRemaining <= 0) {
            NextWave();
        }
    }

    private void NextWave() {
        earnMoney = true;
        waveNum++;
        enemiesRemaining = (waveNum * 10 + (waveNum * waveNum) / 2)*6;
        Spawn();
        return;
    }

    private void Spawn() {
        //pick 6 places to spawn
        for (int i = 0; i< 6; i++) {
            int j = Random.Range(0, 16);
            Vector3 pos = spawnPointArray[j].transform.position;
            GameObject newHole = Instantiate(hole, pos, Quaternion.identity);
            int rand = Random.Range(0, 10);
            if (rand > 1) {
                newHole.GetComponent<EnemySpawn>().enemyID = 0;
            }
            else {
                newHole.GetComponent<EnemySpawn>().enemyID = 1;
            }
            //Debug.Log(rand);
            newHole.GetComponent<EnemySpawn>().BeginSpawn(enemiesRemaining/6);
        }
    }


    private void LateUpdate()
    {
        if (earnMoney) {
            //count down to 0, then reset
            interval -= Time.deltaTime;
            if (interval <= 0)
            {
                interval = intervalMax;
                earnMoney = false;

            }
        }

    }
}
