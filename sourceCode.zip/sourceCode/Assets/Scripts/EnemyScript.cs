﻿using UnityEngine;
using Pathfinding;

public class EnemyScript : MonoBehaviour
{

    GameObject player;
    [SerializeField]
    private float damage = 10f;

    private AudioSource audioData;

    void Start()
    {
        //find player and set ai target to player
        player = GameObject.Find("Player");
        transform.GetComponent<AIDestinationSetter>().target = player.transform;
        audioData = GetComponent<AudioSource>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        HealthScript target = collision.transform.GetComponent<HealthScript>();
        EnemyScript friend = collision.transform.GetComponent<EnemyScript>();
        //checks if collidng with enemy to not dmaage other enemy
        if (target != null && friend == null)
            {
                target.TakeDamage(damage);
                audioData.Play(0);
        }
        
    }

}
