using UnityEngine;

public class ShopItem : InteractScript
{
    [SerializeField]
    protected GameObject player;
    public int price = 10;
    [SerializeField]
    protected bool isSingleUse = true;

    private void Start()
    {
        player = GameObject.Find("Player");
    }

    public override void Interact() {

        //take money away from player
        if (player.GetComponent<MoneyScript>().MakePurchase(price)) {
            //give upgrade, gun, whatever
            Give();
            if (isSingleUse) {
                Destroy(gameObject);
            }
        }


        return;
    }

    protected virtual void Give() {
        //this function shouldnt ever be called unless something is wrong, it will be overriden by child classes
        player.GetComponent<Gun>().UpgradeDamage(price); //upgrade damage by price by default
        return;
    }
}
