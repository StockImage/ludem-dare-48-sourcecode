using UnityEngine;

public class BuyGun : ShopItem
{

    [SerializeField]
    private int id = 1;
    protected override void Give()
    {
        player.transform.GetChild(0).GetComponent<WeaponSwitchScript>().GiveGun(id); // shotgun id is 1
        return;
    }
}
