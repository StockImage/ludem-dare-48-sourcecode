using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Camera mainCam;
    public float moveSpeed = 5f;
    public Rigidbody2D rb;
    [SerializeField]
    private float interactRange = 2f;

    Vector2 inputDirection;
    public Vector2 lookDirection;

    public PlayerInput controls;
    Vector2 mousePos;
    Vector2 mousePosScreen;

    private AudioSource audioData;
    public void Awake()
    {
        controls = new PlayerInput();

        //movement
        controls.Player.MovePlayer.performed += context => inputDirection = context.ReadValue<Vector2>();
        controls.Player.MovePlayer.canceled += _ => inputDirection = Vector2.zero;
        controls.Player.MousePosition.performed += context => mousePos = context.ReadValue<Vector2>();
        controls.Player.Interact.performed += _ => AttemptInteract();
        audioData = GetComponent<AudioSource>();
    }

    private void OnEnable()
    {
        controls.Enable();
    }

    private void OnDisable()
    {
        controls.Disable();
    }

    void AttemptInteract()
    {
        //interactables layer is layer 8
        int interactablesLayer = 1 << 8;
        RaycastHit2D hit = Physics2D.Raycast(transform.position, lookDirection, interactRange, interactablesLayer);
        //Debug.Log("interacting");
        if (hit)
        {
            //Debug.Log("found target");
            InteractScript target = hit.transform.GetComponent<InteractScript>();
            if (target != null)
            {
                audioData.Play(0);
                target.Interact();
            }
        }
    }

    void Update()
    {
        mousePosScreen = mainCam.ScreenToWorldPoint(mousePos);
    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + inputDirection * moveSpeed * Time.deltaTime);
        lookDirection = mousePosScreen - rb.position;
        float angle = Mathf.Atan2(lookDirection.y, lookDirection.x) * Mathf.Rad2Deg - 90f;

        rb.rotation = angle;
    }

    public void UpgradeSpeed(int amount)
    {
        moveSpeed += amount;
        return;
    }
}
