using UnityEngine;

public class DrillRotator : MonoBehaviour
{
    [SerializeField]
    GameObject drillBase;
    [SerializeField]
    private float baseSpinSpeed = 10f;
    float spinSpeed = 0f;
    // Update is called once per frame
    void Update()
    {
        int drillLevel = drillBase.GetComponent<Drill>().level;
        if ( drillLevel > 0)
        {
            //spin
            spinSpeed = baseSpinSpeed * drillLevel * Time.deltaTime;
            transform.Rotate(transform.rotation.x, transform.rotation.y, spinSpeed);
        }
    }
}
