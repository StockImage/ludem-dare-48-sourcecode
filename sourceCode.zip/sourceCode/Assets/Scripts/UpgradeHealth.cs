using UnityEngine;
using TMPro;

public class UpgradeHealth : ShopItem
{

    [SerializeField]
    private int amount = 1;
    [SerializeField]
    GameObject indicator;
    [SerializeField]
    string text;
    private int level = 0;

    private void Start()
    {
        indicator = GameObject.Find("Indicator");
        player = GameObject.Find("Player");
    }
    protected override void Give()
    {
        player.transform.GetComponent<HealthScript>().UpgradeHealth(amount);
        indicator.GetComponent<TextMeshPro>().text = text;
        indicator.GetComponent<TextScript>().DisplayText();
        //make price go up
        level++;
        price = 12 * level + (level * level) / 8;
        string priceString = price.ToString();
        transform.GetChild(0).GetComponent<TextMeshPro>().text = "$" + priceString;
        return;
    }
}
