using UnityEngine;
using TMPro;

public class TextScript : MonoBehaviour
{
    private bool timerStart = false;
    private float timer;
    [SerializeField]
    private float timerMax = 3f;
    public void DisplayText() {
        gameObject.SetActive(true);
        //wait
        timer = timerMax;
        timerStart = true;
        return;
    }

    private void LateUpdate()
    {
        if (timerStart)
        {
            //count down to 0, then character is vulnerable again
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                timer = timerMax;
                timerStart = false;
                gameObject.SetActive(false);
            }
        }
    }
}
