using UnityEngine;

public class MoneyScript : MonoBehaviour
{
    public int money = 10;
    public bool MakePurchase(int amount) {

        if (money - amount < 0)
        {
            //not enough cash
            return false;
        }
        else {
            money -= amount;

            return true;
        }

        
    }

    public void GainMoney(int amount) {
        money += amount;
        return;

    }
}
