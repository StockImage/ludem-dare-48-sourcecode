﻿using UnityEngine;

public class Bullet : MonoBehaviour
{
    //default damage
    public float damage = 5f;
    public bool isPiercing = false;
    public bool isExplosive = false;
    [SerializeField]
    GameObject explosionPrefab;
    //contingency in case bullet flies into infinity
    [SerializeField]
    private float lifeTime = 10; //seconds

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!isExplosive)
        {
            HealthScript target = collision.transform.GetComponent<HealthScript>();
            if (target != null)
            {
                target.TakeDamage(damage);
            }
            if (!isPiercing)
            {
                Destroy(gameObject);
            }
        }
        else {
            //create explosion
                      
            //not the best way to do things, but it works for now
            Instantiate(explosionPrefab, transform.position, transform.rotation);
            Destroy(gameObject);
        }
    }

    //destroy prohectile after certain time
    private void LateUpdate()
    {
        //count down to 0, then destroy bullet
        lifeTime -= Time.deltaTime;
        if (lifeTime <= 0)
        {
            Destroy(gameObject);
        }
    }
}
