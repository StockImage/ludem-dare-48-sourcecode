using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPickup : MonoBehaviour
{
    public int amount = 10;
    private void OnCollisionEnter2D(Collision2D collision)
    {
        
        HealthScript target = collision.transform.GetComponent<HealthScript>();
        if (target != null)
        {
            target.Heal(amount);
        }
        Destroy(gameObject);
            
        }
    }


