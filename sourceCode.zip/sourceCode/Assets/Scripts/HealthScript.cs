﻿using UnityEngine;
using UnityEngine.AI;

public class HealthScript : MonoBehaviour
{
    public float health = 30f;
    public float maxHealth = 30f;
    private bool vulnerable = true;
    [SerializeField]
    private bool hasIFrames = false;
    private float timer = 0f;
    [SerializeField]
    private float timerMax = 0.5f; // max i frames
    private bool timerStart = false;
    //scuffed
    [SerializeField]
    private bool isPlayer = false;
    [SerializeField]
    private GameObject UI;
    [SerializeField]
    private GameObject item;

    //scuffed
    [SerializeField]
    private GameObject spawnController;

    void Start() {
        timer = timerMax;
        vulnerable = true;
        spawnController = GameObject.Find("EnemySpawnController");

    }
    public void TakeDamage(float amount)
    {
        if (vulnerable) {
            health -= amount;
            if (hasIFrames)
            {
                StartIFrames();
            }
            if (health <= 0f)
            {
                Die();
            }
        }
    }

    public void Heal(int amount) {
        health += amount;
        if (health>maxHealth) {
            health = maxHealth;
        }
    }

    void Die()
    {
        if (gameObject.GetComponent<EnemyScript>() != null) {
            spawnController.GetComponent<SpawnController>().EnemyDied();
        }
        if (isPlayer)
        {
            UI.GetComponent<GameOver>().BeginGameOver();
        }
        else {
            
            float rand = Random.Range(0f,30f);
            if (rand <= 1) {
                //drop item 
                Instantiate(item, transform.position, Quaternion.identity);
            }
        }
        Destroy(gameObject);
    }

    public void UpgradeHealth(int amount)
    {
        maxHealth += amount;
        health += amount;
        return;
    }

    //timer for invinvibilty frames, will only be using for player
    private void StartIFrames()
    {
        vulnerable = false;
        timerStart = true;
        return;
    }

    //used for timere
    private void LateUpdate()
    {
        if (timerStart) {
            //count down to 0, then character is vulnerable again
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                timer = timerMax;
                vulnerable = true;
                timerStart = false;
            }
        }
    }
}
