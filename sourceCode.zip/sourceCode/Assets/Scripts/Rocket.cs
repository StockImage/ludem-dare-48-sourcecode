using UnityEngine;

public class Rocket : MonoBehaviour
{
    [SerializeField]
    GameObject explosionPrefab;
    //contingency in case bullet flies into infinity
    [SerializeField]
    private float interval = 30; //seconds

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //create explosion
        //not the best way to do things
        Instantiate(explosionPrefab, transform.position, transform.rotation);

        Destroy(gameObject);
    }

    //destroy prohectile after certain time
    private void LateUpdate()
    {
        //count down to 0, then destroy bullet
        interval -= Time.deltaTime;
        if (interval <= 0)
        {
            Destroy(gameObject);
        }
    }
}
