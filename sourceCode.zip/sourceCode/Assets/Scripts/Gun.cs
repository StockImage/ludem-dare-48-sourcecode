﻿using UnityEngine;
using System.Collections;

public class Gun : MonoBehaviour
{
    [SerializeField]
    private Transform firePoint;
    [SerializeField]
    private GameObject bulletPrefab;
    [SerializeField]
    private float bulletForce = 60f;

    [SerializeField]
    public string gunName = "pistol";
    //a scuffed way of doing things
    [SerializeField]
    private bool isAutomatic = false;
    private bool fireHeld = false;
    [SerializeField]
    private bool isPiercing = false;
    [SerializeField]
    private bool isExplosive = false;
    
    [SerializeField]
    public float bloomRange = 0.5f;
    //allows easy customisation of bullet damge for each weapon
    [SerializeField]
    private int bulletDamage = 6;
    [SerializeField]
    private int maxBulletDamage = 999;

    [SerializeField]
    private int numOfProjectiles = 1;
    [SerializeField]
    private int maxNumOfProjectiles = 999;

    [SerializeField]
    public int ammoInMagazine;
    [SerializeField]
    private int magazineSize = 7;
    [SerializeField]
    private int maxMagSize = 999;
    [SerializeField]

    public int ammoInReserve = 49;
    [SerializeField]
    private int maxReserve = 999;

    private float interval = 0f;
    [SerializeField]
    private float intervalMax = 0.2f;

    //does the gun reload one round at a time (true) or the whole magazine (false). e.g shotgun would be true
    [SerializeField]
    private bool isReloadPerBullet = false;
    //time for reload to complete. If above variable is true, reload time is per round
    [SerializeField]
    private float reloadTime = 1f;
    private bool isReloading = false;

    private PlayerInput controls;

    private AudioSource audioData;

    [SerializeField]
    private GameObject reloadIndicator;

    public void Awake()
    {
        controls = new PlayerInput();
        controls.Player.Fire.started+= _ => AttemptShoot();
        controls.Player.Fire.canceled += _ => fireHeld = false;
        controls.Player.Reload.performed += _ => attemptReload();
        audioData = GetComponent<AudioSource>();

    }
    /*
    private void Start()
    {
        reloadIndicator = GameObject.Find("Reloading Indicator");
    }*/

    private void OnEnable()
    {
        controls.Enable();
        isReloading = false;
    }

    private void OnDisable()
    {
        controls.Disable();
    }

    void Fire()
    {
        audioData.Play(0);
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        bullet.GetComponent <Bullet>().damage = bulletDamage;
        //bit of a scuffed way of doing things
        bullet.GetComponent<Bullet>().isPiercing = isPiercing;
        bullet.GetComponent<Bullet>().isExplosive = isExplosive;
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();

        float bloom = Random.Range(-bloomRange, bloomRange);

        Vector3 bulletDirection = firePoint.up * bulletForce;

        GameObject player = GameObject.Find("Player");

        //Debug.Log(bloom);

        bulletDirection += bloom * player.transform.right;

        rb.AddForce(bulletDirection, ForceMode2D.Impulse);
    }

    void AttemptShoot() {
        if (isAutomatic) {
            fireHeld = true;
        }
        Shoot();
        return;

    }

    void Shoot()
    {
        //if player reloading, cancel reload
        if (isReloading == false)
        {
            if (ammoInMagazine > 0)
            {      
                for (int i = 0; i < numOfProjectiles; i++)
                {
                    ammoInMagazine--;
                    Fire();
                }
            }
            else
            {
                //empty, need to reload
                //Debug.Log("Empty, got to reload");
                attemptReload();

            }
        }
        /*else
        {
            //Debug.Log("stopping reload to fire");
            StopCoroutine("Reload");
            isReloading = false;
        }*/

    }

    void attemptReload()
    {
        if (isReloading == false)
        {
            isReloading = true;
            //Debug.Log("ATTEMPTING RELOAD");
            reloadIndicator.gameObject.SetActive(true);
            StartCoroutine("Reload");
            reloadIndicator.gameObject.SetActive(false);
        }
        else
        {
            //Debug.Log("already reloading");
        }
    }

    IEnumerator Reload()
    {
        //Debug.Log("Starting reload");
        //animator.SetBool("Reloading", true);
        //isReloading = true;
        if (isReloadPerBullet == false && ammoInMagazine < magazineSize)
        {
            isReloading = true;
            if (ammoInMagazine >= 0)
            {
                ammoInReserve += ammoInMagazine;
            }
            
            ammoInMagazine = 0;
            //take away 0.25 seconds so player cant immediatly shoot when reload animation is done, if negative nothing bad happens
            yield return new WaitForSeconds(reloadTime - 0.25f);

            if (ammoInReserve < magazineSize)
            {
                //if not enough reserve ammo to make full magazine, fill mag with what is left
                ammoInMagazine = ammoInReserve;
                ammoInReserve = 0;
            }
            else
            {
                ammoInMagazine = magazineSize;
                ammoInReserve -= magazineSize;
            }
        }
        else if (isReloadPerBullet == true && ammoInMagazine < magazineSize)
        {
            isReloading = true;
            //must be per round, so loop until gun is full
            while (ammoInMagazine < magazineSize && ammoInReserve > 0)
            {
                yield return new WaitForSeconds(reloadTime - 0.25f);
                ammoInMagazine++;
                ammoInReserve--;

            }
        }

        //Debug.Log("no longer reloading");
        //used for reload animation
        //animator.SetBool("Reloading", false);
        yield return new WaitForSeconds(0.25f);
        isReloading = false;

    }
    public void ReceiveAmmo(int numOfMags) {
        ammoInReserve += numOfMags*magazineSize;
        if (ammoInReserve > maxReserve) {
            ammoInReserve = maxReserve;
        }
        return;

    }

    public void UpgradeMagCapacity(int amount)
    {
        magazineSize += amount;
        if (magazineSize > maxMagSize)
        {
            magazineSize = maxMagSize;
        }
        return;
    }

    public void UpgradeDamage(int amount)
    {
        bulletDamage += amount;
        if (bulletDamage > maxBulletDamage)
        {
            bulletDamage = maxBulletDamage;
        }
        return;
    }

    public void UpgradeProjectiles(int amount)
    {
        numOfProjectiles += amount;
        if (numOfProjectiles > maxNumOfProjectiles)
        {
            numOfProjectiles = maxNumOfProjectiles;
        }
        return;
    }

    private void LateUpdate()
    {/*
        if (isReloading)
        {
            reloadIndicator.gameObject.SetActive(true);
        }
        else {
            reloadIndicator.gameObject.SetActive(false);
        }*/
        //Debug.Log(fireHeld);
        if (fireHeld) {
            //count down to 0, then destroy bullet
            interval -= Time.deltaTime;
            if (interval <= 0)
            {
                Shoot();
                interval = intervalMax;
            }
            
        }
    }

    //not the best way to do things
    private void Update()
    {
        if (isReloading)
        {
            reloadIndicator.gameObject.SetActive(true);
        }
        else {
            reloadIndicator.gameObject.SetActive(false);
        }
    }
}
