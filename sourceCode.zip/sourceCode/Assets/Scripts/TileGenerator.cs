﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TileGenerator : MonoBehaviour
{

    //[SerializeField]
    //private GameObject tileToSpawn;

    private Tile tileToSpawn;
    public Tile terrainTile1;
    public Tile terrainTile2;
    public Tile terrainTile3;
    public Tile terrainTile4;
    public Tilemap terrainTileMap;
    Vector3Int currentCell;

    protected Vector2 spawnPos;

    // in unity units
    public float tileWidth = 1f;
    public float tileHeight = 0.6f;

    public float xOffset = 0f;
    public float yOffset = 0f;

    //num of tiles to spawn
    public int terrainWidth = 100;
    public int terrainHeight = 100;

    void Start()
    {
        
        //Width goes right
        for (int i = 0; i < terrainWidth; i++)
        {
            //height goes up
            for (int j = 0; j < terrainHeight; j++)
            {

                spawnPos.x = xOffset + i*tileWidth;
                spawnPos.y = yOffset + j*tileHeight;
                currentCell = terrainTileMap.WorldToCell(spawnPos);
                //returns number between 1 and 5, NOT including 5
                int num = Random.Range(1, 5);
                switch (num)
                {
                    case 1:
                        tileToSpawn = terrainTile1;
                        break;
                    case 2:
                        tileToSpawn = terrainTile2;
                        break;
                    case 3:
                        tileToSpawn = terrainTile3;
                        break;
                    case 4:
                        tileToSpawn = terrainTile4;
                        break;
                    default:
                        tileToSpawn = terrainTile1;
                        break;

                }

                terrainTileMap.SetTile(currentCell, tileToSpawn);
                //Instantiate(tileToSpawn, spawnPos, Quaternion.identity);
            }

        }
    }

}
