using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//abstarct as it will be overriden
public abstract class InteractScript : MonoBehaviour
{
    public abstract void Interact();
}
