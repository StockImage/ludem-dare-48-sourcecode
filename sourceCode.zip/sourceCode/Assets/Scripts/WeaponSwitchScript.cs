using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponSwitchScript : MonoBehaviour
{

    public PlayerInput controls;
    public int selectedWeapon = 0;
    [SerializeField]
    private int numOfWeapons = 4;
    [SerializeField]
    private bool[] weaponArray = {true,false,false,false}; //only pistol unlocked by default
    public void Awake()
    {
        controls = new PlayerInput();

        controls.Player.ChangeWeapon.performed += context => ChangeWeaponScroll(context.ReadValue<float>());
        controls.Player.Hotkey1.performed += _ => ChangeWeaponDirect(0);
        controls.Player.Hotkey2.performed += _ => ChangeWeaponDirect(1);
        controls.Player.Hotkey3.performed += _ => ChangeWeaponDirect(2);
        controls.Player.Hotkey4.performed += _ => ChangeWeaponDirect(3);
    }

    private void OnEnable()
    {
        controls.Enable();
    }

    private void OnDisable()
    {
        controls.Disable();
    }

    void Start()
    {
        SelectWeapon();
    }

    void ChangeWeaponDirect(int input)
    {
        if (weaponArray[input]) {
            selectedWeapon = input;
            SelectWeapon();
        }
    }
    void ChangeWeaponScroll(float input)
    {
        //Debug.Log(input);
        int previousSelectedWeapon = selectedWeapon;
        if (input > 0)
        {
            selectedWeapon++;
            //if number goes higher than 3, set to first weapon
            if (selectedWeapon > (numOfWeapons-1))
            {
                selectedWeapon = 0;

            }
            //avoid weapons not yet unlocked
            while (weaponArray[selectedWeapon]==false) {
                selectedWeapon++;
                //Debug.Log(selectedWeapon);

                if (selectedWeapon > (numOfWeapons - 1))
                {
                    selectedWeapon = 0;
                
                }
            }
            
        }
        else if (input < 0)
        {
            selectedWeapon--;
            //if number goes lower than 0, set to last weapon
            if (selectedWeapon < 0)
            {
                selectedWeapon = (numOfWeapons - 1);
            }
            //avoid weapons not yet unlocked
            while (weaponArray[selectedWeapon] == false)
            {
                selectedWeapon--;
                //Debug.Log(selectedWeapon);
            
                if (selectedWeapon < 0)
                {
                    selectedWeapon = (numOfWeapons-1);
                }
            }
        }
        if (previousSelectedWeapon != selectedWeapon)
        {
            SelectWeapon();
        }
    }

    void SelectWeapon()
    {
        int i = 0;
        foreach (Transform weapon in transform)
        {
            if (i == selectedWeapon && weaponArray[selectedWeapon] == true)
            {
                weapon.gameObject.SetActive(true);
            }
            else
            {
                weapon.gameObject.SetActive(false);
            }
            i++;
        }
    }

    public void GiveGun(int gunID) {
        //if weapon isnt unlokced, unlock it
        if (weaponArray[gunID] == false)
        {
            weaponArray[gunID] = true;
            //give four mags
            transform.GetChild(gunID).GetComponent<Gun>().ReceiveAmmo(4);
        }
        else {
            //already unlocked, just give ammo
            transform.GetChild(gunID).GetComponent<Gun>().ReceiveAmmo(4);

        }
        return;
    }
}
