using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class UI : MonoBehaviour
{
    [SerializeField]
    private GameObject player;
    [SerializeField]
    private GameObject manager;
    [SerializeField]
    private TextMeshProUGUI healthDisplay;
    [SerializeField]
    private TextMeshProUGUI ammoDisplay;
    [SerializeField]
    private TextMeshProUGUI waveDisplay;
    [SerializeField]
    private TextMeshProUGUI moneyDisplay;

    //scuffed way of doing this
    [SerializeField]
    private GameObject[] weaponArray;

    // Update is called once per frame
    void Update()
    {
        //chekc hp and ammo
        string hpString = player.GetComponent<HealthScript>().health.ToString();
        string maxHpString = player.GetComponent<HealthScript>().maxHealth.ToString();
        string healthOutput = "HP: " + hpString + "/" + maxHpString;
        healthDisplay.GetComponent<TextMeshProUGUI>().text = healthOutput;

        //run through each gun
        for (int i = 0; i < 4; i++) {
            if (weaponArray[i].activeSelf)
            {
                string magAmmoString = weaponArray[i].GetComponent<Gun>().ammoInMagazine.ToString();
                string reserveAmmoString = weaponArray[i].GetComponent<Gun>().ammoInReserve.ToString();
                string ammoOutput = "AMMO: " + magAmmoString + "/" + reserveAmmoString;
                ammoDisplay.GetComponent<TextMeshProUGUI>().text = ammoOutput;
            }
        }
        //check money
        string amount = player.GetComponent<MoneyScript>().money.ToString();
        string moneyOutput = "Money: $" + amount;
        moneyDisplay.GetComponent<TextMeshProUGUI>().text = moneyOutput;
        //check wave
        string waveString = manager.GetComponent<SpawnController>().waveNum.ToString();
        waveDisplay.GetComponent<TextMeshProUGUI>().text = "Wave: " + waveString;
    }
}
