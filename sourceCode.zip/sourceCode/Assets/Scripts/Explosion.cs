using UnityEngine;

public class Explosion : MonoBehaviour
{
    //default damage
    public float damage = 50f;

    //contingency in case bullet flies into infinity
    [SerializeField]
    private float interval = 0.1f; //seconds

    private void OnCollisionEnter2D(Collision2D collision)
    {
        HealthScript target = collision.transform.GetComponent<HealthScript>();
        if (target != null)
        {
            target.TakeDamage(damage);
        }

        Destroy(gameObject);
    }

    //destroy prohectile after certain time
    private void LateUpdate()
    {
        //count down to 0, then destroy bullet
        interval -= Time.deltaTime;
        if (interval <= 0)
        {
            Destroy(gameObject);
        }
    }
}
