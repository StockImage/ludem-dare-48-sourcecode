using UnityEngine;
using TMPro;

public class Drill : InteractScript
{
    [SerializeField]
    protected GameObject player;
    [SerializeField]
    private int earnings = 1; //per set time interval
    [SerializeField]
    private float interval = 0;
    [SerializeField]
    private float intervalMax = 1; // in seconds
    public int price = 10;
    [SerializeField]
    public int level = 0; // 0 is inactive, multiplier
    [SerializeField]
    private bool isActive = false; // to avoid unneccasary calculations and calls

    [SerializeField]
    private GameObject spawnController;


    private void Start()
    {
        spawnController = GameObject.Find("EnemySpawnController");
        player = GameObject.Find("Player");
    }
    public override void Interact()
    {

        //take money away from player
        if (player.GetComponent<MoneyScript>().MakePurchase(price))
        {
            //make drill earn more money
            level++;
            if (level > 0 && isActive == false) {
                //to avoid unneccesary assignment after the first
                isActive = true;
            }
            //but make enemies tougher
            //make price go up
            price = 12*level + (level*level)/8;
            string priceString = price.ToString();
            transform.GetChild(2).GetComponent<TextMeshPro>().text = "$" + priceString;
        }


        return;
    }

    private void LateUpdate()
    {
        bool waveActive = spawnController.GetComponent<SpawnController>().earnMoney;
        if (isActive && waveActive) {
            //count down to 0, then reset
            interval -= Time.deltaTime;
            if (interval <= 0)
            {
                interval = intervalMax;
                //give player money
                player.GetComponent<MoneyScript>().GainMoney(earnings * level);
            }
        }
        
    }
}
